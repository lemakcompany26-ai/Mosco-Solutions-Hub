-- Mosco Solutions Hub weekly Pro + affiliate links migration.
-- Review before applying to a production database. Safe to run more than once for these objects.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  plan text not null default 'free' check (plan in ('free','pro')),
  pro_until timestamptz,
  created_at timestamptz not null default now()
);

alter table public.profiles add column if not exists plan text not null default 'free';
alter table public.profiles add column if not exists pro_until timestamptz;

create table if not exists public.pro_payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  reference text not null unique,
  provider_reference text unique,
  amount_kobo integer not null check (amount_kobo > 0),
  currency text not null default 'NGN' check (currency = 'NGN'),
  plan_days integer not null default 7 check (plan_days = 7),
  status text not null default 'pending' check (status in ('pending','success','failed')),
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.affiliate_links (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(trim(title)) between 1 and 120),
  url text not null check (url like 'https://%'),
  description text,
  active boolean not null default true,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null default 'General',
  question text not null,
  answer text not null,
  created_at timestamptz not null default now()
);

create or replace function public.mosco_handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, display_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''))
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists mosco_auth_user_created on auth.users;
create trigger mosco_auth_user_created after insert on auth.users for each row execute procedure public.mosco_handle_new_user();
insert into public.profiles(id, display_name) select id, coalesce(raw_user_meta_data->>'full_name','') from auth.users on conflict (id) do nothing;

alter table public.profiles enable row level security;
alter table public.pro_payments enable row level security;
alter table public.affiliate_links enable row level security;
alter table public.questions enable row level security;

-- A signed-in user can read only their own profile. Do not grant client-side plan updates.
drop policy if exists "profile owner read" on public.profiles;
create policy "profile owner read" on public.profiles for select to authenticated using (id = auth.uid());
drop policy if exists "payment owner read" on public.pro_payments;
create policy "payment owner read" on public.pro_payments for select to authenticated using (user_id = auth.uid());
drop policy if exists "active affiliates public read" on public.affiliate_links;
create policy "active affiliates public read" on public.affiliate_links for select to anon, authenticated using (active = true);
drop policy if exists "admin affiliate insert" on public.affiliate_links;
create policy "admin affiliate insert" on public.affiliate_links for insert to authenticated with check ((auth.jwt()->'app_metadata'->>'role') = 'admin' and created_by = auth.uid());
drop policy if exists "admin affiliate update" on public.affiliate_links;
create policy "admin affiliate update" on public.affiliate_links for update to authenticated using ((auth.jwt()->'app_metadata'->>'role') = 'admin') with check ((auth.jwt()->'app_metadata'->>'role') = 'admin');
drop policy if exists "admin affiliate delete" on public.affiliate_links;
create policy "admin affiliate delete" on public.affiliate_links for delete to authenticated using ((auth.jwt()->'app_metadata'->>'role') = 'admin');
drop policy if exists "question owner read" on public.questions;
create policy "question owner read" on public.questions for select to authenticated using (user_id = auth.uid());
drop policy if exists "question owner insert" on public.questions;
create policy "question owner insert" on public.questions for insert to authenticated with check (user_id = auth.uid());

-- Atomic activation prevents duplicate webhook deliveries granting extra days twice.
create or replace function public.activate_verified_weekly_pro(p_reference text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.pro_payments%rowtype; start_at timestamptz; until_at timestamptz;
begin
  select * into p from public.pro_payments where reference = p_reference for update;
  if not found then raise exception 'Payment reference not found'; end if;
  if p.status = 'success' then
    select pro_until into until_at from public.profiles where id = p.user_id;
    return jsonb_build_object('status','already_processed','pro_until',until_at);
  end if;
  if p.amount_kobo <> 250000 or p.currency <> 'NGN' or p.plan_days <> 7 then raise exception 'Payment does not match weekly Pro'; end if;
  select pro_until into start_at from public.profiles where id = p.user_id for update;
  if start_at is null or start_at < now() then start_at := now(); end if;
  until_at := start_at + interval '7 days';
  update public.profiles set plan='pro', pro_until=until_at where id=p.user_id;
  update public.pro_payments set status='success', verified_at=now(), provider_reference=p.reference where id=p.id and status='pending';
  return jsonb_build_object('status','success','pro_until',until_at);
end; $$;
revoke all on function public.activate_verified_weekly_pro(text) from public, anon, authenticated;
grant execute on function public.activate_verified_weekly_pro(text) to service_role;

revoke insert, update, delete on public.profiles from anon, authenticated;
grant select on public.profiles, public.pro_payments, public.affiliate_links, public.questions to authenticated;
grant select on public.affiliate_links to anon;
grant insert, update, delete on public.affiliate_links to authenticated;
grant insert on public.questions to authenticated;

# Mosco Solutions Hub (updated starter)

React + TypeScript + Supabase starter with KoraPay weekly Pro checkout, verified webhook, Study Buddy branding and an admin-managed affiliate-link list.

## Plan
- Pro: ₦2,500 NGN for 7 days.
- Pro is granted only after server-side KoraPay verification confirms `success`, the expected reference, NGN currency and the exact amount.
- Screenshot uploads are not treated as proof of payment in this automated flow.

## 1. Run on Replit / Android
1. Upload or import this project ZIP in a Node.js workspace.
2. Copy `.env.example` to `.env` and fill `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` (the Supabase publishable key).
3. Run `npm install`, then `npm run dev`.
4. Set the deployed website's URL in Supabase Auth redirect configuration.

## 2. Supabase database
Run `supabase/migration-weekly-pro.sql` in Supabase SQL Editor. Review against your existing schema first. It creates/updates the profiles, pro_payments, affiliate_links and questions tables/policies and the atomic `activate_verified_weekly_pro` RPC. Existing app-specific tables are not dropped.

If your existing `profiles` table does not have `plan` and `pro_until`, add these columns with a reviewed migration before deploying. If your `questions` table has different required columns, adjust the Study Buddy insert to match it.

## 3. Supabase Edge Function secrets
Set these in Supabase Dashboard → Edge Functions → Secrets:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` (secret, server-only)
- `KORAPAY_SECRET_KEY` (live secret, server-only)
- `APP_BASE_URL` (the deployed website URL, e.g. `https://your-site.example`)
- `GEMINI_API_KEY` (server-only)

Never put secret/service-role keys in `.env` variables beginning with `VITE_`, frontend code, GitHub, or chat.

## 4. Deploy functions
Deploy these folders as Supabase Edge Functions:
- `korapay-initialize`
- `korapay-webhook`
- `korapay-verify`
- `ask`

The webhook is intentionally public and has `verify_jwt = false` in `supabase/config.toml`; it validates KoraPay's `x-korapay-signature` HMAC-SHA256 and then independently queries KoraPay's charge verification endpoint before activating Pro. Keep the webhook URL public so KoraPay can reach it.

Set the webhook URL in Kora dashboard to:
`https://YOUR_PROJECT_ID.supabase.co/functions/v1/korapay-webhook`

KoraPay docs: https://developers.korapay.com/docs/checkout-redirect and https://developers.korapay.com/docs/webhooks

## 5. Admin affiliate links
The admin page uses the Supabase JWT `app_metadata.role === "admin"` claim. Set this role only from a trusted server/admin workflow, not from a user-editable profile field. In Supabase Auth, assign `app_metadata.role` to `admin` to your administrator account and sign out/in to refresh the token. The admin can publish HTTPS URLs and remove links; public users can read only active links.

## 6. Test before live launch
1. Use KoraPay test credentials first, not live credentials.
2. Test successful, failed, pending, duplicate-webhook, wrong-amount and wrong-currency cases.
3. Verify one successful payment adds seven days once and a webhook retry does not add more time.
4. Check Supabase function logs and KoraPay dashboard transaction records.
5. After tests pass and your KoraPay account is cleared for live payments, use the live secret only in Edge Function Secrets.

## Important limitations / production hardening
- This starter was generated in this environment and dependencies were not installed, so a full build/test against your actual Supabase project has not been performed.
- The frontend is a focused starter rather than the full previous lesson-centre screens. Merge its payment/admin pieces into your existing app if you need to preserve all original pages.
- KoraPay's webhook signature uses the JSON-stringified `data` object as described in its documentation; confirm against real test events before live rollout.
- Add server-side rate limits, audit logs, and monitoring before serving many users.
